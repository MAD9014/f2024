# Project for Github Pages

This is the sample project to be used for the github assignment in MAD9014 Fall 2023.
